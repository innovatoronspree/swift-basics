//Dictionaries
/* A dictionary is a type of hash table, providing fast access to the entries it contains. Each entry in the table is identified using its key, which is a hashable type such as a string or number. You use that key to retrieve the corresponding value, which can be any object. In other languages, similar data types are known as hashes or associated arrays. */
import UIKit

var dic1 : [String:String] = [:] //empty dictionary
var dic2 = [String:String]() //empty dictionary

dic1 = ["CA":"California", "NYC":  "New York City", "ND" :"New Delhi"]

print(dic1)

for (k,v) in dic1
{
    print("Key is: \(k) and value is: \(v)")
}

print(dic1["ND"])

dic1.updateValue("China",forKey: "CA")

print(dic1["CA"])

dic1.removeValue(forKey: "CA")
print(dic1["CA"])


var namesOfIntegers = [Int:String]()

namesOfIntegers[3] = "Three"
namesOfIntegers[44] = "Forty four"

print(namesOfIntegers)

namesOfIntegers = [:] //empties the dictionary

print(namesOfIntegers)

var airports : [String:String] = ["YXZ":"Toronto Pearson ","NDI":"Indira Gandhi International airport ","NYC":"New YORK City Airport "]

print("The airports dictonary has: \(airports.count) items.")

if airports.isEmpty{
    print("The airport dictionary is empty")
}

airports["LHR"] = "London Airport"

airports["LHR"] = "London Heathrow Airport"

airports["JAI"] = "Jaipur International Airport"

airports["JAI"] = nil
for (key,value) in airports
{
    print("The key is : \(key) and values is : \(value)")
}
for air in airports.keys
{
    print("The key is: \(air) ")
}
for val in airports.values
{
    print("The values are: \(val)")
}


