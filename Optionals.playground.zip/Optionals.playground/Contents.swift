import UIKit

/* struct Person
{
    let firstName : String
    let middleName : String?
    let lastName : String
    
    func printFullName(){
        // print("\(firstName) \(middleName) \(lastName)") //This is not useful we are not using optionals correctly
        //print("\(firstName) \(middleName) \(lastName)") //not good
        let middle = middleName ?? ""
       /* if middleName == nil{
            middle = ""
        } Meaning of above statement */
        print("\(firstName) \(middle) \(lastName)")
        
    }
}

//say we are creating a form in which middleName may or may not be there so we would have to make use if checks, for that purpose we have optionals in swift which let users specify which data could be nil and  which data is guaranteed to be not nil
var person1  = Person(firstName : "Salman",middleName:nil, lastName : "Khan")
person1.printFullName()

var person2 = Person(firstName:"Neil", middleName : "Nitin", lastName: "Mukesh")
person2.printFullName() */

class Person
{
    let firstName : String
    let middleName : String?
    let lastName : String
    let spouse : Person?
    
    init(firstName:String, middleName:String?, lastName: String, spouse: Person?)
    {
        self.firstName = firstName
        self.middleName = middleName
        self.lastName = lastName
        self.spouse = spouse
    }
    func getFullName() -> String
    {
        
        let middle = middleName ?? ""
        return "\(firstName) \(middle) \(lastName)"
    }
}

var p1 = Person(firstName: "Mukesh", middleName: "Dhirubhai", lastName:"Ambani", spouse:Person(firstName: "Nita", middleName: "Mukesh", lastName: "Ambani", spouse: nil))

var p2 = Person(firstName: "Sal", middleName: nil, lastName:"Khan", spouse:nil)


//using optional chaining, we can run some logic on something that is optional
if let spouseName = p1.spouse?.getFullName()
{
    print("\(spouseName)")
}
else
{
    print("\(p1.getFullName) does not have a spouse")
}

if let spouseName = p2.spouse?.getFullName()
{
    print("\(spouseName)")
}
else
{
    print("\(p2.getFullName()) does not have a spouse")
}


for i in 1...100
{
    if i%3==0 && i%5==0{
        print("FizzBuzz")
    }
    else if i%3==0 {
        print("Fizz")
    }
    else if i%5==0{
        print("Buzz")
    }
    else {
        print(i)
    }
}
let average = Int(10.3 + 4.0) / 2
print(average)
