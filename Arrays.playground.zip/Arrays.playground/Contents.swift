//: Playground - noun: a place where people can play

//Arrays

import UIKit

var employeeSalaries : [Double] = [40000.0, 54000.0, 100000.0, 20000.0]
print(employeeSalaries)
print(employeeSalaries.count)
print(employeeSalaries.capacity)
employeeSalaries.append(39000.34) //function
print(employeeSalaries.capacity)
print(employeeSalaries.count)     //property
//HERE WE SEE A VERY IMPORTANT PROPERTY THAT WHEN WE TRY TO APPEND THE SIZE OF THE ARRAY BY ONE BY USING APPEND, THE CAPACITY DOUBLES WHICH IS A WASTE OF MEMORY
/* Different ways of defining an array */
   let oddNumbers  = [1,3,5,7,9]
 //empty array
 var emptyDoubles : [Double] = []
 var emptyFloats : Array<Float> = Array()
 // If we need an array that is pre-initialized with a fixed number of default values
 var digitCounts = Array(repeating : 0, count : 10);
 print(digitCounts)

employeeSalaries.remove(at: 0)
print(employeeSalaries.count);


//LOOPS
print()
for word in oddNumbers
{
    print(word)
}
print()
oddNumbers.forEach{ word in
    print(word)
}
var x = 0
repeat{
    
    employeeSalaries[x] += 0.10*employeeSalaries[x]
    x += 1
}
while(x<employeeSalaries.count)

print(employeeSalaries)
//repeat-while is same as do-while loop
print()
var index = 0
for index in 1...5
{
    print(index)
}

for x in 1..<oddNumbers.count
{
    print(x)
}

