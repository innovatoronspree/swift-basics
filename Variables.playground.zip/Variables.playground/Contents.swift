//: Playground - noun: a place where people can play
// Swift is a type save language
import UIKit

var message = "Hey there my buddy" //Declaration : Type Inference
print(message)

var name = "Bob"
var age = 23 //Integer
var weight = 75.3 // Double
var isOrganDonor = false //Boolean

print(weight)

print(name + " lost weight")

print(weight-5);

let eyeColor = "blue"
// eyeColor = "green" we cannot change let constant //immutable
print(eyeColor)

var mes : String = "This is a string" //Explicit type Declaration
var fname = "Jenna"
var lname = "Smith"
print(fname + " " + lname) //String concatenation

var newMessage = "Hi my name is \(fname) and I am \(age) years old" //String interpolation
print(newMessage)

newMessage.append(" and I like cars")
print(newMessage)

// numbers
var age2 = 15 //Integer using type inference
var price = 10.99 //Double - default type in swift in case of float and double
var aPrice : Float = 10.99
//print(price+aPrice) //this will give error : Binary operator cannot be applied to Float and Double

var personAge : Int = 15
var thePrice : Double = 10.99

var length = 10
var width = 5
let area = length*width

print(area)

var health = 100
var poisonDamage = 15
health -= poisonDamage //compound assignment operator
print(health)
var potion = 20

health += potion
print(health)

var students = 30
var treats = 500

let treatsPerStudent = treats/students
print(treatsPerStudent)
print(500/30)

let remainder = treats%students //In swift called remainder operator
print(remainder)

var tlength : Double = 3
var twidth : Double = 4

let hypotenuse = sqrt(pow(tlength,2) + pow(twidth,2))
print(hypotenuse)

var quantity : Int = 5
var price_1 : Double = 10
var cost = Double(quantity)*price_1 //casting quantity
print(cost)

