//: Playground - noun: a place where people can play

import UIKit
var amITheBestStudentEver : Bool = true

amITheBestStudentEver = false

if true == false || true == true {
print("heyThere")
}

var hasDataFinishedDownloading : Bool = false // 1 == 2
//..
//..
hasDataFinishedDownloading = true
//Load UI and other app features
//Comparison operators result Bool that is boolean values true and false

var bankBalance = 400
var itemToBuy = 100

if bankBalance > itemToBuy {
    print("puchased item")
    bankBalance -= itemToBuy
}
if itemToBuy > bankBalance {
    print("Work harder and earn more")
}
if itemToBuy == bankBalance
{
    bankBalance = 0
    print("Hey buddy, your bank balance is now zero")
}

//Comparing strings
var book_title1 = "Harry Potter"
var book_title2 = "Harry Motter"

if book_title1 != book_title2
{
    print("Please enter the correct spelling")
}
else if book_title2.characters.count > 10 {
    print("Find a new title for the book")
    
}
else {
    print("Book looks great send it to printer")
}

if !hasDataFinishedDownloading {
    print("Loading data")
}
else
{
    print("Downloaded")
}

//Logical operators
// ! Logical Not Operator OR uranary prefix operator

let allowedEntry = false

if !allowedEntry
{
    print("Access Denied")
}
let enteredDoorCode = true
let passedRetinaScan = false
let iAmAkshayKumar = true

if enteredDoorCode && passedRetinaScan || iAmAkshayKumar{
    print("Welcome")
}
else{
    print("Access Denied Again")
}

let hasDoorKey = false
let knowsOverridePassword = true

if hasDoorKey || knowsOverridePassword {  //First RHS is evaluated
    print("Welcome")
}
else{
    print("You won't be able to get in")
}
