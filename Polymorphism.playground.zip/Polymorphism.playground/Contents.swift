//Polymorphism : Occuring in many forms
// Types : Compile time that is just method overloading and Run Time that is just method overriding

import UIKit

//method overloading
class sum
{
    func summing(a : Int, b : Int)
    {
        print("Sum is \(a+b).")
    }
    func summing(a : Int, b: Int, c: Int)
    {
        print("Sum is \(a+b+c).")
    }
}
var Moverloading = sum()
Moverloading.summing(a:2,b:3)//both funcs have same name but different type signature i.e vars
Moverloading.summing(a:1,b:2,c:3) //and their types

class Animal
{
    func sound()
    {
        print("Sound of music")
    }
}
class Cat :  Animal
{
    override func sound()
    {
        print("Meow")
    }
}
class Dog : Animal
{
    override func sound()
    {
        print("Barking")
    }
}

var a : Animal

a = Cat() //At run time what the variable is referring to, that method will be called
a.sound()

a = Dog()
a.sound()

class Shape
{
    var area : Double?
    func calculateArea(valA: Double, valB: Double){
        
    }
}

class Triangle:  Shape
{
    override func calculateArea(valA: Double, valB: Double) {
        area = (valA*valB)/2
    }
}

class Rectangle :  Shape
{
    override func calculateArea(valA: Double, valB: Double) {
        area = valA*valB
    }
}

