//Inheritance

import UIKit

class Vehicle
{
    var tyres = 4
    var make : String?
    var model : String?
    var currentSpeed : Double  //If we don't initialize this it gives an error : Stored property 'currentSpeed" without initial value prevents synthesized initializers
    init(make : String?, model : String?)
    {
        print("I am the parent")
        currentSpeed = 0
        self.make = make ?? " "
        self.model = model ?? " "
        
        
    }
    func drive(speedIncrease : Double) -> Double
    {
        currentSpeed += speedIncrease*2
        return currentSpeed
    }
    func brake()
    {
        
    }
}

//Lets create subclass

class SportsCar : Vehicle
{
    override init(make: String?, model: String?) {
        super.init(make : make, model : model)
        print("I am the child")
    }
    override func drive(speedIncrease: Double) -> Double
    {
        currentSpeed += speedIncrease*3
        return currentSpeed
    }
}

var R8 = SportsCar(make: "Audi", model: "R8")
print("The increased speed of the car \(R8.model) is \(R8.drive(speedIncrease: 30))");

class Truck : Vehicle
{
    override init(make : String?, model : String?){
        super.init(make: make,model : model)
        }
    override func drive(speedIncrease: Double) -> Double {
        currentSpeed += speedIncrease*3
        return currentSpeed
    }
}

