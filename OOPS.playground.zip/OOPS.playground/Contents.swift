//OOPS

import UIKit

//create a blueprint and then create multiple copies

class Vehicle
{
    var tires = 4
    var headlights = 2
    var horsePower = 468
    var model = " "
    func drive()
    {
        //accerlerate the vehicle
        
    }
    func brake(){
        
    }
    init()
    {
        
    }
}

let bmw = Vehicle() //INSTANTIATION -> This is an object
bmw.model = "328i"

let ford = Vehicle()
ford.model = "F150"
ford.brake()

//OBJECTS CANNOT BE COPIED, THEY ARE PASSED BY REFERENCE

func passByReference(vec : Vehicle)
{
    vec.model = "Mac n Cheese"
}

print(ford.model + " :before calling function.")

passByReference(vec: ford)


print()
print(ford.model + " :after calling function gets, model modified as we are just changing reference in memory.")

var age = 10

func passByValue(age : Int)
{
    //age = age+10
    // age cannot be modified as it is a let constant
    // that is a parameter in a func in swift cannot be modified
}
passByValue(age: 10)
