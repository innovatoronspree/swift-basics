import UIKit

/*:
 ### Code Example
 */

var namesOfIntegers = [Int: String]()

namesOfIntegers[3] = "three"
namesOfIntegers[4] = "four"
namesOfIntegers = [:]

var ageDictionary = ["John": 33, "Samantha": 14]

var airports: [String: String] = ["YYZ": "Toronto Pearson", "LAX": "Los Angeles International"]

print("The airports dictionary has: \(airports.count) items")

if airports.isEmpty {
    print("The airports dictionary is empty!")
}

airports["LHR"] = "London"
airports["LHR"] = "London Heathrow"
airports["DEV"] = "Coder International"

airports["DEV"] = nil

for (airportCode, airportName) in airports {
    print("\(airportCode): \(airportName)")
}

for key in airports.keys {
    print("Key: \(key)")
}

for val in airports.values {
    print("Value: \(val)")
}

/*:
 ### Exercise
 
 Consider a real-world dictionary that you might read on your desk.
 
 1.  Create an animal dictionary where the key is the name of the animal and the value should be a string which represents the definition of the animal
 2.  Add ten animals to this dictionary
 3.  Iterate through the dictionary and print the keys and values in this format: `"Animal: X -- Description: Y"` where X is the name of the animal and Y is the description of the animal
 4.  Clear out the entire dictionary and then instead use this dictionary to store United States state abbrieviations and full names (ie CA : California)
 5. Store ten state names and abbreviations in this dictionary and then print them in this format: `Y: X` where Y is the name of the state and where X is the abbreviation
 6. Set the first state you chose to `nil`
 7. Iterate through the array and print each key and value and see what happened to that state you set to nil
 */

var animal : [String:String] = ["Tiger":"Fiercful wild beast", "Lion":"Lord of the jungle", "Dog":"Man's most faithful friend", "Cat":"Sweet and swift", "Rabbit" : "Cute animals", "Piranha" : "Deadly fish found in the Amazon rainforest", "Sloth" : "Sweet leaf eating animals","Caterpillars":"Slow moving vibrant worms","Bear":"Sloth like looking omnivores", "Polar Bears" : "Cute bears found in the Arctic region"]


for (key,value) in animal
{
    print("The animal is :\(key) - \(value)")
}
 //When we print the list, it is not printed in order in which it was added because dictionaries store data in unordered form.
print()
animal = [:]
print(animal)

print()
var states  = [String : String]()
states["Rajasthan"] = "Jaipur"
states["Madhya Pradesh"] = "Raipur"
states["Uttar Pradesh"] = "Lucknow"
states["Andhra Pradesh"] = "Hyderabad"
states["Punjab"] = "Chandigarh"
states["Haryana"] = "Chandigarh"
states["Kerela"] = "Thiruvanthampuram"
states["Maharahtra"] = "Mumbai"
states["Karanatka"] = "Bengaluru"
states["Uttrakhand"] = "Shimla"

for (state,city) in states
{
    print("The state is \(state) and its capital is \(city).")
}

print()
states["Uttrakhand"] = nil //deleting or removing key with Uttrakhand

for (state,city) in states
{
    print("The state is \(state) and its capital is \(city).")
}

